/*  This program, server4.c, begins in similar vein to our last server,
    with the notable addition of an include for the signal.h header file.
    The variables and the procedure of creating and naming a socket are the same.  */

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
/*
static void child_signal( int x )
{
	printf("Client closed connection\n");
}
*/
int main()
{
    int server_sockfd, client_sockfd;
    int server_len, client_len;
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;

    signal(SIGCHLD, SIG_IGN);
/*    struct sigaction sa;
    sa.sa_handler = child_signal;
    sa.sa_flags = SA_NOCLDWAIT;
    sigaction(SIGCHLD, &sa, NULL );
*/
    server_sockfd = socket(AF_INET, SOCK_STREAM, 0);

    server_address.sin_family = AF_INET;
//    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
//    server_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(9734);
    printf("I am going to listen on %d \n",server_address.sin_port);
//    server_address.sin_port = 9734;
    server_len = sizeof(server_address);
    if (bind(server_sockfd, (struct sockaddr *)&server_address, server_len)== -1)
    {
	perror("Unable to bind");
	exit(2);
    }

/*  Create a connection queue, ignore child exit details and wait for clients.  */

    listen(server_sockfd, 5);

    while(1) {
        char ch;
	int data = 0;
        printf("server waiting\n");

/*  Accept connection.  */

        client_len = sizeof(client_address);
        client_sockfd = accept(server_sockfd, 
            (struct sockaddr *)&client_address, &client_len);

/*  Fork to create a process for this client and perform a test to see
    whether we're the parent or the child.  */

        if(fork() == 0) {

/*  If we're the child, we can now read/write to the client on client_sockfd.
    The five second delay is just for this demonstration.  */
            read(client_sockfd, &data, 4);
//            read(client_sockfd, &ch, 1);
	    printf ("I got %d from client\n", data );
            ch++;
	    data = ntohl(data);
	    printf ("I am now going to send back %d\n", ++data);

//            write(client_sockfd, &ch, 1);
            write(client_sockfd, &data, 4);
            close(client_sockfd);
            exit(0);
        }

/*  Otherwise, we must be the parent and our work for this client is finished.  */

        else {
            close(client_sockfd);
//	    wait();
        }
    }
}

